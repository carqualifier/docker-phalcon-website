# Generating LDT Documentation

The LDT classes are documented using PHPDoc comments. You can generate
documentation using [phpDocumentor](http://www.phpdoc.org/docs/latest/getting-started/installing.html).

See phpDocumentor's [Quickstart](http://www.phpdoc.org/docs/latest/guides/running-phpdocumentor.html#quickstart) guide.

`phpdoc run --sourcecode -d . -t ./doc`
