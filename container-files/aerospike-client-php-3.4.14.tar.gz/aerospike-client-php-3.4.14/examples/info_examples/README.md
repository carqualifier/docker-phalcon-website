# Info Method Examples

### Basic Info Operations
`standard.php` gives an example of the info(), infoMany() and getNodes() info
methods.

```bash
php standard.php --host=192.168.119.3 -a
```

