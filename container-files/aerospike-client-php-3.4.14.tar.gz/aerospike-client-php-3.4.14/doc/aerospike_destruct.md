
# Aerospike::__destruct

Aerospike::__desruct - Destructor for the Aerospike object

## Description

```
public void Aerospike::__destruct ( void )
```

**Aerospike::__destruct** will disconnect from the Aerospike DB cluster and
clean up resources.

## Parameters

This method has no parameters.

